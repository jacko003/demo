#!/bin/bash

createAddressBook(){
 if [ -e addressbook.txt ]
 then
  echo "Address Book already created"
 else
  touch addressbook.txt
  echo "Address book created"
 fi
}

insertARecord(){
 echo
 while true
 do
  echo "To add a record to address book, enter in this format:"
  echo "\"last name,first name,email,phone number\" (no spaces)"
  echo "Example: verma,rajat,rajatverma@gmail.com,1234567890"
  echo "To quit press 'q'"
  read aInput
  if [ "$aInput" == "q" ]
  then
   break
  fi
  echo $aInput >> addressbook.txt
  echo "Record inserted in address book."
  echo
 done
}

viewRecord(){
 echo
 while true
 do
  echo "To display a record, enter the last name (case sensitive)"
  echo "To quit, press 'q'"
  read dInput
  if [ "$dInput" == "q" ]
  then
   break
  fi
  echo
  echo "Display records for \"$dInput\":"
  grep ^"$dInput" addressbook.txt
  RETURNSTATUS=$?
  if [ $RETURNSTATUS -eq 1 ]
  then
   echo "No records found with last name \"$dInput\"."
  fi
  echo
 done
}

modifyRecord(){
 echo
 while true
 do
  echo "To modify a record, enter any search string (e.g. last name or email)"
  echo "Enter 'q' to quit"
  read eInput
  if [ "$eInput" == "q" ]
  then
   break
  fi
  echo
  echo "Listing records for \"$eInput\":"
  grep -n "$eInput" addressbook.txt
  RETURNSTATUS=$?
  if [ $RETURNSTATUS -eq 1 ]
  then
   echo "No record found for \"$eInput\""
  else
   echo
   echo "Enter the line number of the entry you want to edit:"
   read lineNumber
   echo
   echo "Enter new record in format:"
   echo "\"last name,first name,email,phone number\" (no spaces)"
   read edit
   sed -i "${lineNumber}s/.*/$edit/" addressbook.txt
   echo "Address book updated"
  fi
  echo
 done
}

deleteRecord(){
 echo
 while true
 do
  echo "To remove a record, enter any search string (e.g. last name or email)"
  echo "Enter 'q' to quit"
  read rInput
  if [ "$rInput" == "q" ]
  then
   break
  fi
  echo
  echo "Listing records for \"$rInput\":"
  grep -n "$rInput" addressbook.txt
  RETURNSTATUS=$?
  if [ $RETURNSTATUS -eq 1 ]
  then
   echo "No records found for \"$rInput\""
  else
   echo
   echo "Enter the line number of the record you want to delete:"
   read lineNumber
   sed -i "${lineNumber}d" addressbook.txt
   echo "Record removed from address book."
  fi
  echo
 done
}

searchRecord(){
 echo
 while true
 do
  echo "To search for a record, enter any search string (e.g. last name or email)"
  echo "Format: \"last name,first name,email,phone number\""
  echo "Enter 'q' to quit"
  read sInput
  if [ "$sInput" == "q" ]
  then
   break
  fi
  echo
  echo "Listing records for \"$sInput\":"
  grep "$sInput" addressbook.txt
  RETURNSTATUS=$?
  if [ $RETURNSTATUS -eq 1 ]
  then
   echo "No records found for \"$sInput\"."
  fi
  echo
 done
}

echo
if [ -e addressbook.txt ]
then
 lastCharOfFile=$(tail -c 1 addressbook.txt)
 if [ -n "$lastCharOfFile" ]
 then
  echo >> addressbook.txt
 fi
fi

echo "Address Book Menu"
echo "1 --> Create Address Book"
echo "2 --> Insert a Record"
echo "3 --> View Records"
echo "4 --> Modify a Record"
echo "5 --> Delete a Record"
echo "6 --> Search Records"
echo "7 --> Exit"
echo
read input

case $input in
 1) createAddressBook;;
 2) insertARecord;;
 3) viewRecord;;
 4) modifyRecord;;
 5) deleteRecord;;
 6) searchRecord;;
 7) exit;;
 *) echo "Invalid choice";;
esac
echo
