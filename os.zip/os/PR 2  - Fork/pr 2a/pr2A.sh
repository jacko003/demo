#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char *argv[]) {
 int val[10], ele, i, j, n, temp;
 pid_t pid;
 char *cval[10];

 printf("Enter the size of array: ");
 scanf("%d", &n);

 printf("Enter %d numbers:\n", n);
 for(i = 0; i < n; i++) scanf("%d", &val[i]);

 printf("Elements entered: ");
 for(i = 0; i < n; i++) printf("%d ", val[i]);

 for(i = 1; i < n; i++) {
  for(j = 0; j < n - 1; j++) {
   if(val[j] > val[j + 1]) {
    temp = val[j];
    val[j] = val[j + 1];
    val[j + 1] = temp;
   }
  }
 }

 printf("\nSorted elements: ");
 for(i = 0; i < n; i++) printf("%d ", val[i]);

 printf("\nEnter element to search: ");
 scanf("%d", &ele);
 val[i] = ele;

 for(i = 0; i < n + 1; i++) {
  char a[sizeof(int)];
  snprintf(a, sizeof(a), "%d", val[i]);
  cval[i] = malloc(strlen(a) + 1);
  strcpy(cval[i], a);
 }
 cval[i] = NULL;

 pid = fork();
 if(pid == 0) {
  execv(argv[1], cval);
  perror("Error in execv call");
 }
 return 0;
}
