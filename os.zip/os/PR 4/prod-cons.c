#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define BUFFER_SIZE 5
#define TRUE 1

typedef int buffer_item;

buffer_item buffer[BUFFER_SIZE];
int counter = 0;

pthread_mutex_t mutex;
sem_t full, empty;
pthread_t *producers, *consumers;
pthread_attr_t attr;

int insert_item(buffer_item item) {
  if(counter < BUFFER_SIZE) {
    buffer[counter++] = item;
    return 0;
  } else return -1;
}

int remove_item(buffer_item *item) {
  if(counter > 0) {
    *item = buffer[--counter];
    return 0;
  } else return -1;
}

void *producer(void *param) {
  buffer_item item;
  while(TRUE) {
    sleep(rand() % 3);  // random sleep
    item = rand();
    sem_wait(&empty);
    pthread_mutex_lock(&mutex);
    if(insert_item(item)) fprintf(stderr, "Producer error\n");
    else printf("Producer produced %d\n", item);
    pthread_mutex_unlock(&mutex);
    sem_post(&full);
  }
}

void *consumer(void *param) {
  buffer_item item;
  while(TRUE) {
    sleep(rand() % 3);
    sem_wait(&full);
    pthread_mutex_lock(&mutex);
    if(remove_item(&item)) fprintf(stderr, "Consumer error\n");
    else printf("Consumer consumed %d\n", item);
    pthread_mutex_unlock(&mutex);
    sem_post(&empty);
  }
}

void initialize() {
  pthread_mutex_init(&mutex, NULL);
  sem_init(&full, 0, 0);
  sem_init(&empty, 0, BUFFER_SIZE);
  pthread_attr_init(&attr);
}

int main(int argc, char *argv[]) {
  if(argc != 4) {
    fprintf(stderr, "Usage: %s <mainSleepTime> <numProd> <numCons>\n", argv[0]);
    return -1;
  }

  int mainSleepTime = atoi(argv[1]);
  int numProd = atoi(argv[2]);
  int numCons = atoi(argv[3]);

  initialize();

  producers = malloc(sizeof(pthread_t) * numProd);
  consumers = malloc(sizeof(pthread_t) * numCons);

  for(int i = 0; i < numProd; i++)
    pthread_create(&producers[i], &attr, producer, NULL);
  for(int i = 0; i < numCons; i++)
    pthread_create(&consumers[i], &attr, consumer, NULL);

  sleep(mainSleepTime);

  for(int i = 0; i < numProd; i++) pthread_cancel(producers[i]);
  for(int i = 0; i < numCons; i++) pthread_cancel(consumers[i]);

  free(producers);
  free(consumers);

  printf("Exit the program\n");
  return 0;
}
