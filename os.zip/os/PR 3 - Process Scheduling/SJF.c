#include <stdio.h>

int main() {
  int arrival_time[10], burst_time[10], temp[10];
  int i, smallest, count = 0, time, limit;
  double wait_time = 0, turnaround_time = 0, end;
  float avg_wait, avg_turn;

  printf("Enter total number of processes: ");
  scanf("%d", &limit);

  printf("Enter details of %d processes\n", limit);
  for(i = 0; i < limit; i++) {
    printf("Enter arrival time: ");
    scanf("%d", &arrival_time[i]);
    printf("Enter burst time: ");
    scanf("%d", &burst_time[i]);
    temp[i] = burst_time[i];
  }

  burst_time[9] = 9999;
  for(time = 0; count != limit; time++) {
    smallest = 9;
    for(i = 0; i < limit; i++) {
      if(arrival_time[i] <= time && burst_time[i] < burst_time[smallest] && burst_time[i] > 0)
        smallest = i;
    }
    burst_time[smallest]--;
    if(burst_time[smallest] == 0) {
      count++;
      end = time + 1;
      wait_time += end - arrival_time[smallest] - temp[smallest];
      turnaround_time += end - arrival_time[smallest];
    }
  }

  avg_wait = wait_time / limit;
  avg_turn = turnaround_time / limit;

  printf("\nAverage Waiting Time: %.2f", avg_wait);
  printf("\nAverage Turnaround Time: %.2f\n", avg_turn);

  return 0;
}
